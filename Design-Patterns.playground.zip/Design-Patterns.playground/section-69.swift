var whiteboard = Whiteboard(Circle(), Square())
whiteboard.draw("Red")
